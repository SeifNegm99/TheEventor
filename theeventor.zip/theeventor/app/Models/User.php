<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
	use \Illuminate\Auth\MustVerifyEmail;

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array<int, string>
	 */
	protected $fillable = [
		'first_name',
		'last_name',
		'city_name',
		'email',
		'email_verified_at',
		'password',
		'type',
		'avatar',
	];

	/**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

	/**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function name(): string
    {
    	return $this->first_name . '  ' . $this->last_name;
    }

	public function isCustomerType(): bool
	{
		return $this->type == 1;
	}

	public function isVendorType(): bool
	{
		return $this->type == 2;
	}

	public function isAdminType(): bool
	{
		return $this->type == 3;
	}

	public function getType(): string
	{
		if ($this->isAdminType()) {
		    return 'Admin';
		} elseif ($this->isVendorType()) {
			return 'Vendor';
		}

		return 'Customer';
	}

	public function service(): HasOne
	{
		return $this->hasOne(Service::class);
	}
}
