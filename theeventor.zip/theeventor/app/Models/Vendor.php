<?php

declare(strict_types=1);


namespace App\Models;

class Vendor extends User
{
	protected $table = 'users';

	public function scopeVendor($query)
	{
		return $query->where('type', '=', 2);
	}
}
