<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
	public function profile(Request $request)
	{
		return view('web.user.shared.profile', ['me' => Auth::user()]);
	}

	public function updateAvatar(Request $request)
	{
		if ($request->file('avatar')) {
			$fileName = time().'_'.$request->file('avatar')->getClientOriginalName();
			$filePath = $request->file('avatar')->storeAs('users', $fileName, 'public');

			Auth::user()->update([
				'avatar' => $filePath
			]);
		}
		return back();
	}

	public function updateName(Request $request)
	{
		if (!empty($request->get('first_name')) &&
			!empty($request->get('last_name'))) {
			Auth::user()->update([
				'first_name' => $request->get('first_name'),
				'last_name' => $request->get('last_name'),
			]);
		}
		return back();
	}
}
