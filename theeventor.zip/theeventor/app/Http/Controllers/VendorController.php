<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\File;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class VendorController extends Controller
{
	public function all()
	{
		$images = File::where('user_id', Auth::user()->getAuthIdentifier())->limit(1000)->get();
		return view('web.user.vendor.images', ['me' => Auth::user(), 'images' => $images]);
	}

    public function images(Request $request)
    {
	    $fileModel = new File();
	    $fileName = time().'_'.$request->file('file')->getClientOriginalName();
	    $filePath = $request->file('file')->storeAs('users', $fileName, 'public');
	    $fileModel->name = time().'_'.$request->file('file')->getClientOriginalName();
	    $fileModel->file_path = '/storage/' . $filePath;
	    $fileModel->user_id = Auth::user()->getAuthIdentifier();
	    $fileModel->save();

	    return response()->json(['success'=> $filePath]);
    }

    public function delete(Request $request, File $file)
    {
    	File::where('id', $file->id)->delete();
    	return back();
    }

//    public function services(Request $request)
//    {
//	    return view('web.user.vendor.services', [
//	    	'me' => Auth::user(),
//		    'services' => Service::where('user_id', Auth::user()->getAuthIdentifier())->paginate(12)
//	    ]);
//    }

    public function service(Request $request)
    {
	    $service = Auth::user()->service;
	    if ($service) {
		    $service->images = File::where('service_id', $service->id)->get();
	    }

    	if ($request->isMethod('POST')) {
		    $post = $request->validate([
			    'image' => ['nullable','mimes:jpg,jpeg,png,gif,webp','max:2048'],
			    'category_id' => ['required', 'integer'],
			    'price' => ['required', 'string'],
			    'video' => ['nullable'],
			    'en_name' => ['required', 'string', 'max:255'],
			    'ar_name' => ['nullable', 'string', 'max:255'],
			    'en_description' => ['nullable', 'string', 'min:1'],
			    'ar_description' => ['nullable', 'string', 'min:1'],
			    'long' => ['required', 'string', 'min:1'],
			    'lat' => ['required', 'string', 'min:1'],
		    ]);

		    if (!empty($request->file('image'))) {
			    $fileName = time().'_'.$request->file('image')->getClientOriginalName();
			    $filePath = $request->file('image')->storeAs('services', $fileName, 'public');

			    $post['image'] = "/storage/$filePath";
		    }

		    if ($request->file('video')) {
			    $fileName = time().'_'.$request->file('video')->getClientOriginalName();
			    try {
				    $videoFilePath = $request->file('video')->storeAs('services', $fileName, 'public');

				    $post['video'] = $videoFilePath;
			    } catch (\Exception $e) {
				    $post['video'] = "/storage/services/$fileName";
			    }
		    }
		    $post['user_id'] = Auth::user()->getAuthIdentifier();

		    if (empty($service)) {
			    $service = Service::create($post);
		    } else {
			    $service = Service::where('id', $service->id)->update($post);
		    }

		    $images = File::where('user_id', Auth::user()->getAuthIdentifier())->whereNull('service_id')->get();
		    foreach ($images as $image) {
			    $image->service_id = $service->id;
			    $image->save();
		    }
		    return redirect(route('vendor.service'));
	    }





    	if (!empty($service->id)) {
    	    $images = File::where('user_id', Auth::user()->getAuthIdentifier())->where('service_id', $service->id)->get();
    	} else {
		    $images = File::where('user_id', Auth::user()->getAuthIdentifier())->whereNull('service_id')->get();
	    }
	    return view('web.user.vendor.service', [
	    	'me' => Auth::user(),
		    'images' => $images,
		    'categories' => Category::orderBy('position', 'asc')->get(),
		    'service' => $service
	    ]);
    }
}
