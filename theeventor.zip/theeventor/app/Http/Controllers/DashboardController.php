<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\File;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
	public function index()
	{
		return view('web.admin.services', ['me' => Auth::user(), 'services' => Service::all()]);
	}

	public function updateServiceStatus(Request $request, Service $service, int $status)
	{
		if ($service && ($status == 1 || $status == 0)
		) {
			$service->approved = $status;
			$service->save();
		}
		return back();
	}

	public function service(Request $request, Service $service)
	{
		return view('web.admin.service', [
			'me' => Auth::user(),
			'images' => File::where('user_id', $service->user_id)->where('service_id', $service->id)->get(),
			'service' => $service
		]);
	}
}
