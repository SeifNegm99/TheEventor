<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\File;
use App\Models\Service;
use App\Models\User;
use App\Notifications\MessageSent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;

class WebController extends Controller
{
    public function home()
    {
    	return view('web.home');
    }

    public function services()
    {
    	return view('web.pages.services', ['services' => Service::where('approved', Service::APPROVED)->limit(1000)->get()]);
    }

    public function categories()
    {
    	$categories = Category::orderBy('position', 'asc')->get();
    	return view('web.pages.categories', ['categories' => $categories]);
    }
    public function category(Request  $request, Category $category)
    {
	    $services = Service::where('approved', Service::APPROVED)
		                    ->where('category_id', $category->id)->orderBy('id', 'desc')->get();
    	return view('web.pages.category', ['category' => $category, 'services' => $services]);
    }

    public function service(Request  $request, Service $service)
    {
	    $images = File::where('service_id', $service->id)->get();
	    $service->images = $images;

//	    if ($request->isMethod('POST') && $request->get('sendToUserId') && $request->get('message')) {
	    if ($request->isMethod('POST') && $request->get('sendToUserId') && $request->get('message')) {
//	    	dd(User::find($request->get('sendToUserId')));
		    Notification::sendNow(User::find($request->get('sendToUserId')), new MessageSent($request->get('message'), Auth::user()->getAuthIdentifier()));
	    }
    	return view('web.pages.service', ['service' => $service]);
    }

    public function notifications(Request  $request)
    {
	    $user = $request->user();
	    $myNotifications = $user->notifications;
	    $notifications = [];
	    foreach ($myNotifications as $myNotification) {
		    $notification = $myNotification;
		    $data = $notification->data;
//		    $data['fromUser'] = User::find($myNotification->data['fromUser']);
		    $notification->data = $data;

		    $notifications[] = $notification;
	    }
    	return view('web.pages.notifications', ['me' => $user, 'myNotifications' => $notifications]);
    }
}
