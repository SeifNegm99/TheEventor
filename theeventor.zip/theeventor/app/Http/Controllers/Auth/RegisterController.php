<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreUser;
use App\Models\File;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    protected function createUser(StoreUser $request)
    {
	    $post = $request->validated();

	    $fileName = time().'_'.$request->file('avatar')->getClientOriginalName();
	    $filePath = $request->file('avatar')->storeAs('users', $fileName, 'public');

	    $post['avatar'] = $filePath;

	    $post['password'] = Hash::make($post['password']);
	    $post['email_verified_at'] = new \DateTime();
	    User::create($post);

	    return redirect(route('home'));
    }
}
