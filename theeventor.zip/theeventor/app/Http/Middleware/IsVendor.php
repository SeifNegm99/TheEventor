<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class IsVendor
{
    public function handle(Request $request, Closure $next)
    {
    	$me = Auth::user();
    	if (!$me->isVendorType()) {
    	   return abort(404);
    	}
        return $next($request);
    }
}
