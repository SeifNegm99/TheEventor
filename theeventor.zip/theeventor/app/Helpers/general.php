<?php

function isLoggedIn(): bool
{
	return \Illuminate\Support\Facades\Auth::user() !== null;
}

function isVendor(): bool
{
	return isLoggedIn() && \Illuminate\Support\Facades\Auth::user()->isVendorType();
}

function isCustomer(): bool
{
	return isLoggedIn() && \Illuminate\Support\Facades\Auth::user()->isCustomerType();
}

function isAdmin(): bool
{
	return isLoggedIn() && \Illuminate\Support\Facades\Auth::user()->isAdminType();
}

function avatar():  string
{
	return \Illuminate\Support\Facades\Storage::url(\Illuminate\Support\Facades\Auth::user()->avatar);
}

function vendorImage(string $imageName):  string
{
	return url($imageName);
}

function vendorServiceImage(string $imageName):  string
{
	return url($imageName);
}
