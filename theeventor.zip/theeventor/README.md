## About The Eventor


Installation: 
 ````
composer install
cp .env.example .env
````
change .env database info

````
import theeventor.sql DB
````



Run:
 ````
php -S localhost:8080 -t public
````

