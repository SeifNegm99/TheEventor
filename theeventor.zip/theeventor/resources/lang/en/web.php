<?php

return [
	'siteName' => 'TheEventor',
	'siteTitle' => 'The Eventor',
	'siteDescription' => 'The Eventor Description',
	'siteKeywords' => '',
];
