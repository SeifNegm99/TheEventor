<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">


	<?php $title = (trim($__env->yieldContent('title'))) ? trim($__env->yieldContent('title')) . ' | ' . trans('web.siteName') : trans('web.siteTitle'); ?>
    <title>{{ $title }}</title>


	<?php $description = (trim($__env->yieldContent('description'))) ? trim($__env->yieldContent('description'))  : trans('web.siteDescription'); ?>
    <meta name="description" content='{{$description}}' />

	<?php $keywords = (trim($__env->yieldContent('keywords'))) ? trim($__env->yieldContent('keywords')) : trans('web.siteKeywords'); ?>
    <meta name="keywords" content='{{$keywords}}' />


    @foreach(explode(',', $keywords) as $tag)
        <meta property="article:tag" content="{{$tag}}" />
    @endforeach

    <meta property="og:title" content="{{$title}}" />
    <meta property="og:description" content="{{$description}}" />


    <meta property="og:url" content="{{url()->current()}}" />
    <link rel="canonical" href="{{url()->current()}}" />
    <meta property="og:site_name" content="theeventor" />
	<?php $ogImage = (trim($__env->yieldContent('ogImage'))) ? trim($__env->yieldContent('ogImage')) : url('web/assets/img/logo.png'); ?>
    <meta property="og:image" content="{{$ogImage}}" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:domain" content="theeventor.codeapps.cc">
    <meta name="twitter:title" content="{{ $title }}" />
    <meta name="twitter:image" content="{{$ogImage}}" />
    <meta name="twitter:description" content='{{$description}}' />

    @yield('styles')

    <!-- Favicons -->
    <link href="{{ url('web') }}/assets/img/favicon.png" rel="icon">
    <link href="{{ url('web') }}/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
{{--    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">--}}
{{--    <link rel="preconnect" href="https://fonts.googleapis.com">--}}
{{--    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>--}}
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">

    <link href="{{ url('web') }}/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="{{ url('web') }}/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ url('web') }}/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="{{ url('web') }}/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="{{ url('web') }}/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Template Main CSS File -->
    <link href="{{ url('web') }}/assets/css/style.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</head>

    <body>
        @include('web.layouts.header')
        @yield("content")

        @include('web.layouts.footer')
        @include('web.partials.login')
    </body>



    <!-- Vendor JS Files -->
    <script src="{{ url('web') }}/assets/vendor/aos/aos.js"></script>
    <script src="{{ url('web') }}/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="{{ url('web') }}/assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="{{ url('web') }}/assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="{{ url('web') }}/assets/vendor/php-email-form/validate.js"></script>


    <!-- Vendor JS Files -->
    <script src="{{ url('web') }}/vendor/jquery/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="{{ url('web') }}/js/jquery.geolocation.min.js"></script>

        <!-- Template Main JS File -->

    @yield('scripts')
<script src="{{ url('web') }}/assets/js/main.js"></script>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/62b77ce2b0d10b6f3e79506c/1g6ebvl8o';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
</html>
