<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header border-0">
                <button type="button" class="close" id="close" data-dismiss="modal" aria-label="Close">
{{--                    <span aria-hidden="true">×</span>--}}
                    <svg preserveAspectRatio="xMidYMid meet" data-bbox="25.975 25.975 148.05 148.05" xmlns="http://www.w3.org/2000/svg" viewBox="25.975 25.975 148.05 148.05" role="presentation" aria-hidden="true">
                        <g>
                            <path d="M172.9 167.6L105.3 100l67.6-67.6c1.5-1.5 1.5-3.8 0-5.3s-3.8-1.5-5.3 0L100 94.7 32.4 27.1c-1.5-1.5-3.8-1.5-5.3 0s-1.5 3.8 0 5.3L94.7 100l-67.6 67.6c-1.5 1.5-1.5 3.8 0 5.3s3.8 1.5 5.3 0l67.6-67.6 67.6 67.6c1.5 1.5 3.8 1.5 5.3 0s1.5-3.8 0-5.3z"></path>
                        </g>
                    </svg>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="form-group row">
{{--                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>--}}

                        <div class="col-md-8 m-auto">
                            <input id="email" type="email" placeholder="{{ __('E-Mail Address') }}" class="customInput form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mt-4">
{{--                        <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>--}}

                        <div class="col-md-8 m-auto">
                            <input id="password" type="password" placeholder="{{ __('Password') }}" class="customInput form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mt-4">
                        <div class="col-md-8 m-auto offset-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                <label class="form-check-label" for="remember">
                                    {{ __('Remember Me') }}
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-8 m-auto mt-2">
                            <button type="submit" class="btn btn-dark w-100">
                                {{ __('Login') }}
                            </button>
                        </div>
                        <div class="col-md-8 m-auto mt-2">
                            <a class="btn btn-link" href="{{ route('register') }}">
                                {{ __('Sign up?') }}
                            </a>

                            @if (Route::has('password.request'))
                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    {{ __('Forgot Your Password?') }}
                                </a>
                            @endif
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@section('scripts')
    @parent

    @if($errors->has('email') || $errors->has('password'))
        <script>
			$(function() {
				$('#loginModal').modal({
					show: true
				});
			});
        </script>
    @endif

    <script>
        $(document).ready(function() {
        	$('.close').click(function() {

		        $('#loginModal').modal('toggle');
		        $('.modal-backdrop').remove();
        	});
        });
    </script>
@endsection
