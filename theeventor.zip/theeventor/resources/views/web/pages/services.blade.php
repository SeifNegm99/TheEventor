@extends('web.base')

@section('content')
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    @foreach ($services as $service)
                        <div class="col-sm-4 card-wrapper">
                            <div class="card border-0">
                                <div class="position-relative rounded-circle overflow-hidden mx-auto custom-circle-image">
                                    <img class="w-100 h-100" src="{{ vendorServiceImage($service->image) }}" alt="Card image cap">
                                </div>
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        {{ $service->en_name }}
                                        {{ !empty($service->ar_name) ? ' - ' . $service->ar_name : ''  }}
                                    </h3>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </section>
    </main>
@endsection
