@extends('web.base')

@section('content')
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    @foreach ($categories as $category)
                        <div class="col-sm-4">
                            <div class="card border-0">
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        <a href="{{ route('category', $category) }}" class="btn btn-sm btn-main">
                                            {{ $category->name }}
                                        </a>
{{--                                        {{ !empty($service->ar_name) ? ' - ' . $service->ar_name : ''  }}--}}
                                    </h3>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </section>
    </main>
@endsection
