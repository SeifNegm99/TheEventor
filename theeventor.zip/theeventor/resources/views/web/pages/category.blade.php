@extends('web.base')

@section('content')
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    <h1 class="font_0 mb-5" style="color:#af9453;font-size:56px; line-height:normal; text-align:center;"><span style="letter-spacing:normal;"><span style="font-size:56px;">{{ $category->name }}</span></span></h1>
                    @foreach ($services as $service)
                        <div class="col-sm-4 card-wrapper category">
                            <div class="card border-0">
                                <div class="position-relative">
                                    <a href="{{ route('service', $service) }}">
                                        <img style="height: 497px;width: 100%;object-fit: cover;object-position: center center;" src="{{ vendorServiceImage($service->image) }}" >
                                    </a>
                                </div>
                                <div class="card-body text-center mt-4">
                                    <button class="btn btn-sm btn-success mb-2">{{ $service->price }}</button>
                                    <a href="{{ route('service', $service) }}">
                                        <h3 class="text-uppercase card-title">
                                            {{ $service->en_name }}
                                            {{ !empty($service->ar_name) ? ' - ' . $service->ar_name : ''  }}
                                            <br>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </section>
    </main>
@endsection
