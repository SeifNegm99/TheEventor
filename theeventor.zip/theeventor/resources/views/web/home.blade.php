@extends('web.base')

@section('content')

{{--    @if(Session::has('error'))--}}
{{--        <p class="alert alert-danger"> {!!Session::get('error')!!}</p>--}}
{{--    @endif--}}
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="hero-container" data-aos="zoom-in" data-aos-delay="100">
            <h1 class="mb-4 pb-0 d-flex">Your<br><span class="ms-2">Occasion</span></h1>
            <p class="mb-4 pb-0">Preparations in One Place</p>
            <div class="scrollDown">
                <svg preserveAspectRatio="xMidYMid meet" data-bbox="45.87 4.75 111.491 192.633" xmlns="http://www.w3.org/2000/svg" viewBox="45.87 4.75 111.491 192.633" role="img" aria-labelledby="svgcid-1rs52n-63i94s"><title id="svgcid-1rs52n-63i94s">Services</title>
                    <g>
                        <path d="M156.124 46.421L103.09 5.431a3.245 3.245 0 0 0-4.003.019L47.109 46.44a3.252 3.252 0 0 0-.54 4.568c1.112 1.411 3.233 1.655 4.644.54L98 14.711V194.13c0 1.798 1.202 3.253 3 3.253s3-1.455 3-3.253V14.63l47.969 36.937c.591.457 1.379.68 2.077.68.972 0 1.976-.435 2.618-1.264 1.1-1.42.883-3.463-.54-4.562z"></path>
                    </g>
                </svg>
            </div>
{{--            <i class=" play-btn mb-4">--}}
{{--                <i class="bi bi-arrow-down-short"></i>--}}
{{--            </i>--}}
        </div>
    </section><!-- End Hero Section -->

    <main id="main">

        <section id="services" class="services">
            <div class="container" data-aos="fade-up">
                <div class="row p-5">
                    <div class="d-md-flex d-sm-block justify-content-between align-items-center">
                        <div class="col-md-4 col-sm-12 discover me-5">
                            <h3>SERVICES</h3>

                            <svg preserveAspectRatio="xMidYMid meet" data-bbox="0 0.1 72.349 97.425" xmlns="http://www.w3.org/2000/svg" viewBox="0 0.1 72.349 97.425" role="presentation" aria-hidden="true"><g><path d="M28.5 28.4c5.8 14.2 5.5 31.3 6.1 46.5.3 7.3.4 14.6-1.2 21.7-.1.4.1.8.5.9.4.1.8-.1.9-.5 1.6-7.3 1.6-14.7 1.2-22.1-.5-15.3-.1-32.6-6-46.9-.4-.9-1.9-.5-1.5.4z"></path><path d="M36.2 86.2c.3-9.2 4.9-15.9 10.2-22.9 5-6.8 10.8-13 17.3-18.3.8-.6-.3-1.6-1.1-1.1-7.2 5.7-13.1 12.7-18.6 20-5.2 6.9-9.2 13.5-9.4 22.3 0 .4.3.8.8.8s.8-.4.8-.8z"></path><path d="M52.6 55.5c1.1-5.2-.1-11.5-2.2-16.3-.4-.9-1.7-.1-1.3.8 1.9 4.5 3.1 10.4 2 15.2-.2.9 1.3 1.3 1.5.3z"></path><path d="M43.9 65.9c-.4-4.5-.6-9-1-13.4-.1-1-1.6-1-1.5 0 .4 4.5.6 9 1 13.4.1 1 1.6 1 1.5 0z"></path><path d="M46.3 63.4c6.3-1.3 12.5-3 18.6-5 .9-.3.5-1.8-.4-1.5-6.1 2-12.3 3.7-18.6 5-.9.3-.5 1.7.4 1.5z"></path><path d="M40.1 72.4c5.2-.7 10.4-.3 15.4 1.3.4.1.8-.1.9-.5s-.1-.8-.5-.9c-5.1-1.6-10.5-2.1-15.8-1.4-.9.1-1 1.6 0 1.5z"></path><path d="M29.3 27.7C21 20.8 23.3 6.5 32 1.4L30.9.5c-.6 3.8.4 7 1.2 10.7 1.2 5.8.8 11.8-3 16.7-.6.8.5 1.8 1.1 1.1 2.4-3 3.8-6.6 4-10.5.5-6-2.7-11.7-1.8-17.5.1-.4-.1-.8-.6-.9-.2 0-.4 0-.5.1-9.6 5.6-12.1 21.1-3 28.7.7.5 1.8-.6 1-1.2z"></path><path d="M33 37.6c1.3-7.5 4.3-15.4 11.8-18.6l-1.1-.5c1.7 8.7-4.1 15.5-11.5 19.1-.9.4-.1 1.7.8 1.3 8.1-3.9 14-11.5 12.2-20.8-.1-.4-.5-.6-.9-.5-.1 0-.1 0-.2.1-7.8 3.3-11.2 11.6-12.5 19.5-.2 1 1.2 1.4 1.4.4z"></path><path d="M28.8 29.1c-7.5 1.5-16.4 1.6-22.2-4.3L6.5 26c7.6-4.6 15.9-1.9 22 3.9.3.3.8.3 1.1 0 .3-.3.3-.7 0-1C23 22.7 14 19.8 5.8 24.8c-.4.2-.5.7-.3 1l.1.1c6.1 6.3 15.5 6.2 23.6 4.7 1-.2.6-1.7-.4-1.5z"></path><path d="M63.8 40.3c.8-1.6 2.9-2.3 4.5-1.4s2.3 2.9 1.4 4.5c-.8 1.6-2.9 2.3-4.5 1.4-1.5-.8-2.2-2.7-1.5-4.3"></path><path d="M64.5 40.7c1.5-2.5 5.7-.9 4.5 2.1-.4 1.2-1.7 1.9-2.9 1.6-.1 0-.2-.1-.3-.1-1.3-.7-1.9-2.2-1.3-3.6.3-.9-1.1-1.3-1.5-.4-.7 2.1.3 4.4 2.3 5.3 2 .8 4.2-.2 5-2.2v-.1c.9-1.9.1-4.1-1.8-5h-.1c-1.9-.9-4.2-.2-5.4 1.6-.2.4-.1.8.3 1s.9.2 1.2-.2z"></path><path d="M40.3 47.6c-1.2 1.1-1.3 2.9-.2 4.1.2.3.5.5.9.7 1.8.7 3.9-1.2 3.6-3.1s-1-2.7-3.7-2l-.6.3z"></path><path d="M39.8 47c-1.4 1.3-1.6 3.4-.4 4.9 1.1 1.4 3.2 1.7 4.6.6.2-.1.4-.3.5-.5 1.3-1.4 1.3-3.6.1-5-1.2-1.2-3.3-.8-4.6 0-.4.2-.5.7-.3 1 .2.4.7.5 1 .3.7-.4 1.9-.8 2.6-.3.7.8.8 1.9.2 2.7-.7 1.1-2.3 1.5-3.1.3-.6-.9-.5-2.1.3-2.9.8-.6-.2-1.7-.9-1.1z"></path><path d="M66.5 54.1c-1.6-.2-2.1 1.9-1.7 3.2s2.1 2.2 3.5 2.3 3-.5 3.3-1.9c.1-1.1-.4-2.1-1.3-2.7-.9-.5-1.9-.8-3-.9h-.8z"></path><path d="M66.5 53.4c-2-.1-2.8 2.1-2.5 3.8.3 2.1 2.6 3.3 4.6 3.2s4.1-1.4 3.7-3.6c-.5-2.6-3.3-3.1-5.5-3.4-.9-.1-1.3 1.3-.4 1.5 1.1.1 2.1.3 3.1.7.8.4 1.6 1.2 1.3 2.1-.3.7-.9 1.1-1.6 1.2-1.2.2-2.4-.2-3.3-1.1-.6-.8-.7-2.9.7-2.9.4 0 .7-.4.7-.8-.2-.4-.5-.7-.8-.7z"></path><path d="M57.9 70.9c-2.4.6-2.1 2.4-1.6 3.7.7 1.2 2.1 1.9 3.4 1.6.6-.1 1.2-.3 1.7-.7.9-.9 1.1-2.3.4-3.4-.7-1.1-1.9-1.6-3.2-1.4l-.7.2z"></path><path d="M57.7 70.2c-1.6.3-2.7 1.9-2.4 3.5 0 .2.1.3.1.5.6 2.1 2.8 3.3 4.9 2.7 1.8-.3 3-2.1 2.7-3.9-.1-.4-.2-.7-.3-1-1.1-2-3-2.2-5-1.8-1 .1-.6 1.6.4 1.4s2.1-.3 2.9.6c.8.7.8 1.9.1 2.7-.3.3-.7.5-1.2.6-1.3.3-2.6-.4-3-1.6-.4-.7-.1-1.7.7-2 .2-.1.4-.1.6-.2.4-.2.5-.6.3-1s-.5-.5-.8-.5z"></path><path d="M48.9 35.9c-2.4.6-2.1 2.4-1.6 3.7.7 1.2 2.1 1.9 3.4 1.6.6-.1 1.2-.3 1.7-.7.9-.9 1.1-2.3.4-3.4-.7-1.1-1.9-1.6-3.2-1.4l-.7.2z"></path><path d="M48.7 35.2c-1.6.3-2.7 1.9-2.4 3.5 0 .2.1.3.1.5.6 2.1 2.8 3.3 4.9 2.7 1.8-.3 3-2.1 2.7-3.9-.1-.4-.2-.7-.3-1-1.1-2-3-2.2-5-1.8-1 .1-.6 1.6.4 1.4s2.1-.3 2.9.6c.8.7.8 1.9.1 2.7-.3.3-.7.5-1.2.6-1.3.3-2.6-.4-3-1.6-.4-.7-.1-1.7.7-2 .2-.1.4-.1.6-.2.4-.2.5-.6.3-1s-.5-.5-.8-.5z"></path><path d="M35.5 69.4C30.8 54.2 17.3 39.3.8 38.7c-.5 0-.8.3-.8.7.2 16.5 16.9 36.8 34.8 31.9.4-.1.6-.5.5-.9s-.5-.6-.9-.5c-10.7 2.9-20.9-4.5-26.9-12.8C4.8 53.5 3 49.5 2 45.2c-.8-3.9-1.2-5.4 3.4-4.5 2.7.6 5.2 1.5 7.6 2.8 9.6 4.9 17.8 16.3 20.9 26.4.1.4.5.6.9.5.5-.2.8-.6.7-1z"></path><path d="M.7 41c11.9 8.6 23 19 33.5 29.2.3.3.8.3 1.1 0 .3-.3.3-.7 0-1C24.7 58.9 13.5 48.4 1.5 39.7c-.8-.6-1.5.7-.8 1.3z"></path></g></svg>

                            <a href="{{ route('services') }}" class="discover_btn">
                                DISCOVER
                            </a>
                        </div>
                        <div class="col-md-8 preview">
                            <img src="{{ url('web') }}/assets/img/services-bg.jpeg" class="img-fluid"/>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="gallery" class="services">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="d-md-flex d-sm-block justify-content-between align-items-center">
                        <div class="col-md-8"></div>
                        <div class="col-md-4 col-sm-12 discover me-5">
                            <h3>GALLERY</h3>

                            <svg preserveAspectRatio="xMidYMid meet" data-bbox="0 0.1 72.349 97.425" xmlns="http://www.w3.org/2000/svg" viewBox="0 0.1 72.349 97.425" role="presentation" aria-hidden="true"><g><path d="M28.5 28.4c5.8 14.2 5.5 31.3 6.1 46.5.3 7.3.4 14.6-1.2 21.7-.1.4.1.8.5.9.4.1.8-.1.9-.5 1.6-7.3 1.6-14.7 1.2-22.1-.5-15.3-.1-32.6-6-46.9-.4-.9-1.9-.5-1.5.4z"></path><path d="M36.2 86.2c.3-9.2 4.9-15.9 10.2-22.9 5-6.8 10.8-13 17.3-18.3.8-.6-.3-1.6-1.1-1.1-7.2 5.7-13.1 12.7-18.6 20-5.2 6.9-9.2 13.5-9.4 22.3 0 .4.3.8.8.8s.8-.4.8-.8z"></path><path d="M52.6 55.5c1.1-5.2-.1-11.5-2.2-16.3-.4-.9-1.7-.1-1.3.8 1.9 4.5 3.1 10.4 2 15.2-.2.9 1.3 1.3 1.5.3z"></path><path d="M43.9 65.9c-.4-4.5-.6-9-1-13.4-.1-1-1.6-1-1.5 0 .4 4.5.6 9 1 13.4.1 1 1.6 1 1.5 0z"></path><path d="M46.3 63.4c6.3-1.3 12.5-3 18.6-5 .9-.3.5-1.8-.4-1.5-6.1 2-12.3 3.7-18.6 5-.9.3-.5 1.7.4 1.5z"></path><path d="M40.1 72.4c5.2-.7 10.4-.3 15.4 1.3.4.1.8-.1.9-.5s-.1-.8-.5-.9c-5.1-1.6-10.5-2.1-15.8-1.4-.9.1-1 1.6 0 1.5z"></path><path d="M29.3 27.7C21 20.8 23.3 6.5 32 1.4L30.9.5c-.6 3.8.4 7 1.2 10.7 1.2 5.8.8 11.8-3 16.7-.6.8.5 1.8 1.1 1.1 2.4-3 3.8-6.6 4-10.5.5-6-2.7-11.7-1.8-17.5.1-.4-.1-.8-.6-.9-.2 0-.4 0-.5.1-9.6 5.6-12.1 21.1-3 28.7.7.5 1.8-.6 1-1.2z"></path><path d="M33 37.6c1.3-7.5 4.3-15.4 11.8-18.6l-1.1-.5c1.7 8.7-4.1 15.5-11.5 19.1-.9.4-.1 1.7.8 1.3 8.1-3.9 14-11.5 12.2-20.8-.1-.4-.5-.6-.9-.5-.1 0-.1 0-.2.1-7.8 3.3-11.2 11.6-12.5 19.5-.2 1 1.2 1.4 1.4.4z"></path><path d="M28.8 29.1c-7.5 1.5-16.4 1.6-22.2-4.3L6.5 26c7.6-4.6 15.9-1.9 22 3.9.3.3.8.3 1.1 0 .3-.3.3-.7 0-1C23 22.7 14 19.8 5.8 24.8c-.4.2-.5.7-.3 1l.1.1c6.1 6.3 15.5 6.2 23.6 4.7 1-.2.6-1.7-.4-1.5z"></path><path d="M63.8 40.3c.8-1.6 2.9-2.3 4.5-1.4s2.3 2.9 1.4 4.5c-.8 1.6-2.9 2.3-4.5 1.4-1.5-.8-2.2-2.7-1.5-4.3"></path><path d="M64.5 40.7c1.5-2.5 5.7-.9 4.5 2.1-.4 1.2-1.7 1.9-2.9 1.6-.1 0-.2-.1-.3-.1-1.3-.7-1.9-2.2-1.3-3.6.3-.9-1.1-1.3-1.5-.4-.7 2.1.3 4.4 2.3 5.3 2 .8 4.2-.2 5-2.2v-.1c.9-1.9.1-4.1-1.8-5h-.1c-1.9-.9-4.2-.2-5.4 1.6-.2.4-.1.8.3 1s.9.2 1.2-.2z"></path><path d="M40.3 47.6c-1.2 1.1-1.3 2.9-.2 4.1.2.3.5.5.9.7 1.8.7 3.9-1.2 3.6-3.1s-1-2.7-3.7-2l-.6.3z"></path><path d="M39.8 47c-1.4 1.3-1.6 3.4-.4 4.9 1.1 1.4 3.2 1.7 4.6.6.2-.1.4-.3.5-.5 1.3-1.4 1.3-3.6.1-5-1.2-1.2-3.3-.8-4.6 0-.4.2-.5.7-.3 1 .2.4.7.5 1 .3.7-.4 1.9-.8 2.6-.3.7.8.8 1.9.2 2.7-.7 1.1-2.3 1.5-3.1.3-.6-.9-.5-2.1.3-2.9.8-.6-.2-1.7-.9-1.1z"></path><path d="M66.5 54.1c-1.6-.2-2.1 1.9-1.7 3.2s2.1 2.2 3.5 2.3 3-.5 3.3-1.9c.1-1.1-.4-2.1-1.3-2.7-.9-.5-1.9-.8-3-.9h-.8z"></path><path d="M66.5 53.4c-2-.1-2.8 2.1-2.5 3.8.3 2.1 2.6 3.3 4.6 3.2s4.1-1.4 3.7-3.6c-.5-2.6-3.3-3.1-5.5-3.4-.9-.1-1.3 1.3-.4 1.5 1.1.1 2.1.3 3.1.7.8.4 1.6 1.2 1.3 2.1-.3.7-.9 1.1-1.6 1.2-1.2.2-2.4-.2-3.3-1.1-.6-.8-.7-2.9.7-2.9.4 0 .7-.4.7-.8-.2-.4-.5-.7-.8-.7z"></path><path d="M57.9 70.9c-2.4.6-2.1 2.4-1.6 3.7.7 1.2 2.1 1.9 3.4 1.6.6-.1 1.2-.3 1.7-.7.9-.9 1.1-2.3.4-3.4-.7-1.1-1.9-1.6-3.2-1.4l-.7.2z"></path><path d="M57.7 70.2c-1.6.3-2.7 1.9-2.4 3.5 0 .2.1.3.1.5.6 2.1 2.8 3.3 4.9 2.7 1.8-.3 3-2.1 2.7-3.9-.1-.4-.2-.7-.3-1-1.1-2-3-2.2-5-1.8-1 .1-.6 1.6.4 1.4s2.1-.3 2.9.6c.8.7.8 1.9.1 2.7-.3.3-.7.5-1.2.6-1.3.3-2.6-.4-3-1.6-.4-.7-.1-1.7.7-2 .2-.1.4-.1.6-.2.4-.2.5-.6.3-1s-.5-.5-.8-.5z"></path><path d="M48.9 35.9c-2.4.6-2.1 2.4-1.6 3.7.7 1.2 2.1 1.9 3.4 1.6.6-.1 1.2-.3 1.7-.7.9-.9 1.1-2.3.4-3.4-.7-1.1-1.9-1.6-3.2-1.4l-.7.2z"></path><path d="M48.7 35.2c-1.6.3-2.7 1.9-2.4 3.5 0 .2.1.3.1.5.6 2.1 2.8 3.3 4.9 2.7 1.8-.3 3-2.1 2.7-3.9-.1-.4-.2-.7-.3-1-1.1-2-3-2.2-5-1.8-1 .1-.6 1.6.4 1.4s2.1-.3 2.9.6c.8.7.8 1.9.1 2.7-.3.3-.7.5-1.2.6-1.3.3-2.6-.4-3-1.6-.4-.7-.1-1.7.7-2 .2-.1.4-.1.6-.2.4-.2.5-.6.3-1s-.5-.5-.8-.5z"></path><path d="M35.5 69.4C30.8 54.2 17.3 39.3.8 38.7c-.5 0-.8.3-.8.7.2 16.5 16.9 36.8 34.8 31.9.4-.1.6-.5.5-.9s-.5-.6-.9-.5c-10.7 2.9-20.9-4.5-26.9-12.8C4.8 53.5 3 49.5 2 45.2c-.8-3.9-1.2-5.4 3.4-4.5 2.7.6 5.2 1.5 7.6 2.8 9.6 4.9 17.8 16.3 20.9 26.4.1.4.5.6.9.5.5-.2.8-.6.7-1z"></path><path d="M.7 41c11.9 8.6 23 19 33.5 29.2.3.3.8.3 1.1 0 .3-.3.3-.7 0-1C24.7 58.9 13.5 48.4 1.5 39.7c-.8-.6-1.5.7-.8 1.3z"></path></g></svg>

                            <h3 class="m-0">Unforgettable</h3>
                            <h3 class="m-0">Memories</h3>
                            <a href="#" class="discover_btn">
                                DISCOVER
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </section>


        <!-- ======= Buy Ticket Section ======= -->
        <section id="buy-tickets" class="section-with-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-header">
                    <h2>Buy Tickets</h2>
{{--                    <p>Velit consequatur consequatur inventore iste fugit unde omnis eum aut.</p>--}}
                </div>

                <div class="row">
                    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="card mb-5 mb-lg-0">
                            <div class="card-body">
                                <h5 class="card-title text-muted text-uppercase text-center">Standard Access</h5>
                                <h6 class="card-price text-center">$150</h6>
                                <hr>
                                <ul class="fa-ul">
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                                    <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Community Access</li>
                                    <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Workshop Access</li>
                                    <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>After Party</li>
                                </ul>
                                <hr>
                                <div class="text-center">
                                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#buy-ticket-modal" data-ticket-type="standard-access">Buy Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                        <div class="card mb-5 mb-lg-0">
                            <div class="card-body">
                                <h5 class="card-title text-muted text-uppercase text-center">Pro Access</h5>
                                <h6 class="card-price text-center">$250</h6>
                                <hr>
                                <ul class="fa-ul">
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Community Access</li>
                                    <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Workshop Access</li>
                                    <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>After Party</li>
                                </ul>
                                <hr>
                                <div class="text-center">
                                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#buy-ticket-modal" data-ticket-type="pro-access">Buy Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Pro Tier -->
                    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title text-muted text-uppercase text-center">Premium Access</h5>
                                <h6 class="card-price text-center">$350</h6>
                                <hr>
                                <ul class="fa-ul">
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Community Access</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>Workshop Access</li>
                                    <li><span class="fa-li"><i class="fa fa-check"></i></span>After Party</li>
                                </ul>
                                <hr>
                                <div class="text-center">
                                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#buy-ticket-modal" data-ticket-type="premium-access">Buy Now</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Modal Order Form -->
            <div id="buy-ticket-modal" class="modal fade">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Buy Tickets</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="#">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="your-name" placeholder="Your Name">
                                </div>
                                <div class="form-group mt-3">
                                    <input type="text" class="form-control" name="your-email" placeholder="Your Email">
                                </div>
                                <div class="form-group mt-3">
                                    <select id="ticket-type" name="ticket-type" class="form-select">
                                        <option value="">-- Select Your Ticket Type --</option>
                                        <option value="standard-access">Standard Access</option>
                                        <option value="pro-access">Pro Access</option>
                                        <option value="premium-access">Premium Access</option>
                                    </select>
                                </div>
                                <div class="text-center mt-3">
                                    <button type="submit" class="btn">Buy Now</button>
                                </div>
                            </form>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

        </section><!-- End Buy Ticket Section -->

        <!-- ======= Contact Section ======= -->
        <section id="contact" class="section-bg">

            <div class="container" data-aos="fade-up">

                <div class="section-header">
                    <h2>Contact Us</h2>
                    <p>Nihil officia ut sint molestiae tenetur.</p>
                </div>

                <div class="row contact-info">

                    <div class="col-md-4">
                        <div class="contact-address">
                            <i class="bi bi-geo-alt"></i>
                            <h3>Address</h3>
                            <address>A108 Adam Street, NY 535022, USA</address>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="contact-phone">
                            <i class="bi bi-phone"></i>
                            <h3>Phone Number</h3>
                            <p><a href="tel:+155895548855">+1 5589 55488 55</a></p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="contact-email">
                            <i class="bi bi-envelope"></i>
                            <h3>Email</h3>
                            <p><a href="mailto:info@example.com">info@example.com</a></p>
                        </div>
                    </div>

                </div>

                <div class="form">
                    <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                            </div>
                            <div class="form-group col-md-6 mt-3 mt-md-0">
                                <input type="email" class="form-control" name="email" id="contact_email" placeholder="Your Email" required>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                        </div>
                        <div class="form-group mt-3">
                            <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
                        </div>
                        <div class="my-3">
                            <div class="loading">Loading</div>
                            <div class="error-message"></div>
                            <div class="sent-message">Your message has been sent. Thank you!</div>
                        </div>
                        <div class="text-center"><button type="submit">Send Message</button></div>
                    </form>
                </div>

            </div>
        </section><!-- End Contact Section -->

    </main><!-- End #main -->

@endsection
