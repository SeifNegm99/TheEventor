@extends('web.base')

@section('content')
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    @foreach ($services as $service)
                        <div class="col-sm-4 card-wrapper">
                            <div class="card border-0">
                                <div class="position-relative rounded-circle overflow-hidden mx-auto custom-circle-image">
                                    <img class="w-100 h-100" src="{{ vendorServiceImage($service->image) }}" alt="Card image cap">
                                </div>
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        @if ($service->approved == 1)
                                            <p class="text-success">{{ $service->en_name }}</p>
                                        @elseif ($service->approved == 0)
                                            <p class="text-danger">{{ $service->en_name }}</p>
                                        @else
                                            {{ $service->en_name }}
                                        @endif

                                        {{ !empty($service->ar_name) ? ' - ' . $service->ar_name : ''  }}
                                    </h3>
                                    <div class="col-md-12 d-flex justify-content-center ">
                                        <form method="post" action="{{ route('admin.approve.service', ['service' => $service, 'status' => 1]) }}">
                                            @csrf
                                            <button class="btn btn-sm btn-success me-2">Approve</button>
                                        </form>
                                        <form method="post" action="{{ route('admin.reject.service', ['service' => $service, 'status' => 0]) }}">
                                            @csrf
                                            <button class="btn btn-sm btn-danger me-2">Reject</button>
                                        </form>

                                        <a href="{{ route('admin.view.service', $service) }}" class="btn btn-sm btn-warning">View</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    </main>
@endsection
