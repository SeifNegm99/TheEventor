@extends('web.base')

@section('content')
    <div class="container main-container">
        <div class="row justify-content-center">

            @if($errors->any())
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <strong>
                        {!! implode('<br/>', $errors->all('<span>:message</span>')) !!}
                    </strong>
                </div>
            @endif

                <div class="col-md-10">
                    <div class="card border-0">
                        <div class="card-body">

                            <div class="row mb-4">
                                <div class="col-12 text-center">
                                    @if(!empty($service->image))
                                        <img src="{{ vendorImage($service->image) }}" style="max-width:  200px;" class="mb-4">
                                    @endif
                                </div>
                            </div>

                            <div class="row">

                            @foreach($images as $image)
                                    <div class="col-lg-3 col-md-4 mb-4">
                                        <div class="venue-gallery">
                                            <a href="{{ vendorImage($image->file_path) }}" class="glightbox" data-gall="venue-gallery">
                                                <img src="{{ vendorImage($image->file_path) }}" alt="" class="img-fluid">
                                            </a>
                                        </div>
                                    </div>
                                @endforeach

                            </div>


                            <form method="POST" action="{{ route('update.vendor.service') }}" enctype="multipart/form-data">
                                @csrf



                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <input id="en_name" placeholder="{{ __('English Name') }}" type="text" class="customInput form-control @error('en_name') is-invalid @enderror" name="en_name" value="{{ old('en_name', @$service->en_name) }}" disabled disabled autocomplete="en_name" autofocus>

                                        @error('en_name')
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                        @enderror
                                    </div>

                                    <div class="col-md-6 direction-rtl">
                                        <input id="ar_name" placeholder="{{ __('الاسم بالعربية') }}" type="text" class="customInput form-control @error('ar_name') is-invalid @enderror" name="ar_name" value="{{ old('ar_name', @$service->ar_name) }}" disabled autocomplete="ar_name">

                                        @error('ar_name')
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <div>{!! $service->en_description !!}</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div>{!! $service->ar_description !!}</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <span class="badge badge-secondary bi-text-left">
                                            {{ $service->category->name }}
                                        </span>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>



        </div>
    </div>
@endsection
