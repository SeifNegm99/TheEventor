<?php $__env->startSection('content'); ?>

    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="section-header">
                <h2><?php echo e($service->en_name); ?></h2>
                <p><?php echo e($service->ar_name); ?></p>

            </div>
        </section>
        <section class="about-cards-section mb-5">
            <div class="container-fluid venue-gallery-container" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-10 m-auto">
                    <div class="row">

                        <div class="col-md-6">
                            <div class="card border-0" >
                                <h3 class="main-color bold"><?php echo e($service->user->name()); ?></h3>
                                <p class="main-color f-30 mt-4">
                                    Price
                                </p>
                                <span>Starting From : <?php echo e($service->price); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-6">
                                <div class="well well-sm">
                                    <div class="text-right">
                                        <p class="main-color f-30"> Write A Message</p>
                                        <a class="btn btn-success btn-main border-0" href="#reviews-anchor" id="open-review-box">Submit</a>
                                    </div>

                                    <div class="row" id="post-review-box" style="display:none;">
                                        <div class="col-md-12">
                                            <form accept-charset="UTF-8" action="<?php echo e(route('send.vendor.message', $service)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input id="ratings-hidden" name="rating" type="hidden">
                                                <input id="ratings-hidden" name="sendToUserId" type="hidden" value="<?php echo e($service->user_id); ?>">
                                                <textarea class="form-control animated" cols="50" id="new-review" name="message" placeholder="Enter your review here..." rows="5"></textarea>

                                                <div class="text-right">
                                                    <div class="stars starrr" data-rating="0"></div>
                                                    <a class="btn btn-danger btn-sm btn-primary" href="#" id="close-review-box" style="display:none; margin-right: 10px;">
                                                        <span class="glyphicon glyphicon-remove"></span>Cancel</a>
                                                    <button class="btn btn-success btn-sm " type="submit">Save</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <section class="about-cards-section mb-5">
            <div class="container-fluid venue-gallery-container" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-10 m-auto">
                    <div class="row">
                        <?php $__currentLoopData = $service->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4 mb-4">
                                <div class="venue-gallery">
                                    <a href="<?php echo e(vendorImage($image->file_path)); ?>" class="glightbox" data-gall="venue-gallery">
                                        <img src="<?php echo e(vendorImage($image->file_path)); ?>" alt="" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/service.blade.php ENDPATH**/ ?>