<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    <h1 class="font_0 mb-5" style="color:#af9453;font-size:56px; line-height:normal; text-align:center;"><span style="letter-spacing:normal;"><span style="font-size:56px;"><?php echo e($category->name); ?></span></span></h1>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 card-wrapper category">
                            <div class="card border-0">
                                <div class="position-relative">
                                    <a href="<?php echo e(route('service', $service)); ?>">
                                        <img style="height: 497px;width: 100%;object-fit: cover;object-position: center center;" src="<?php echo e(vendorServiceImage($service->image)); ?>" >
                                    </a>
                                </div>
                                <div class="card-body text-center mt-4">
                                    <button class="btn btn-sm btn-success mb-2"><?php echo e($service->price); ?></button>
                                    <a href="<?php echo e(route('service', $service)); ?>">
                                        <h3 class="text-uppercase card-title">
                                            <?php echo e($service->en_name); ?>

                                            <?php echo e(!empty($service->ar_name) ? ' - ' . $service->ar_name : ''); ?>

                                            <br>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/category.blade.php ENDPATH**/ ?>