<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">

        <section class="about-cards-section mt-5">
            <div class="container">
                <div class="col-md-8 m-auto">
                        <div class="row">

                            <div class="col-md-12 card-wrapper">
                                <div class="card border-0">
                                    <div class="model position-relative rounded-circle overflow-hidden mx-auto custom-circle-image">
                                        <img class="w-100 h-100 modelSign modelImage" src="<?php echo e(avatar()); ?>" alt="Card image cap">
                                        <div class="modelContentInline">
                                            <i class="fas fa-camera"></i>
                                            <label for="avatar">Edit Profile</label>
                                            <form id="profile" method="POST" action="<?php echo e(route('update.profile.avatar')); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input class="form-control" type="file" id="avatar" name="avatar" onChange='updateProfile()' hidden>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card-body text-center mt-4">
                                        <div class="col-md-8 m-auto">
                                            <div class="model">
                                                <h3 class="modelSign text-uppercase card-title"><?php echo e($me->name()); ?></h3>
                                                <div class="modelContent">
                                                    <div class="col-md-12">
                                                        <form method="POST" action="<?php echo e(route('update.profile.name')); ?>" enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="row">
                                                                <div class="col-md-5">
                                                                    <input id="first_name" type="text" class="customInput form-control" name="first_name" value="<?php echo e($me->first_name); ?>" required>
                                                                </div>
                                                                <div class="col-md-5">
                                                                    <input id="last_name" type="text" class="customInput form-control" name="last_name" value="<?php echo e($me->last_name); ?>" required>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <button class="btn btn-sm btn-dark">save</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>


                </div>
            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

    <script type="text/javascript">
	    Dropzone.options.dropzone =
		    {
			    maxFilesize: 12,
			    renameFile: function(file) {
				    var dt = new Date();
				    var time = dt.getTime();
				    return time+file.name;
			    },
			    acceptedFiles: ".jpeg,.jpg,.png,.gif",
			    addRemoveLinks: true,
			    timeout: 5000,
			    success: function(file, response)
			    {
				    console.log(response);
			    },
			    error: function(file, response)
			    {
				    return false;
			    }
		    };
    </script>

    <script>
        function updateProfile()
        {
            $('#profile').submit();
        }
        // $(document).ready(function() {
        //     $('.avatar').change(function() {
        //         console.log('Changed');
        //     });
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/user/shared/profile.blade.php ENDPATH**/ ?>