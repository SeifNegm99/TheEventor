<!-- ======= Footer ======= -->
<footer id="footer">

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong>TheEventor</strong>. All Rights Reserved
        </div>
        <div class="credits">
            by qwe qwe
        </div>
    </div>
</footer><!-- End  Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/layouts/footer.blade.php ENDPATH**/ ?>