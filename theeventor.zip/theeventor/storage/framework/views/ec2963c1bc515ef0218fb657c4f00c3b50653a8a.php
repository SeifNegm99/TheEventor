<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">
        <?php if(isVendor()): ?>
            <section class="about-cards-section">
                <div class="container">
                    <div class="col-md-8 m-auto">
                        <div class="row">
                            <div class="card border-0">
                                <div class="card-body text-center mt-4">
                                    <form method="post" action="<?php echo e(route('upload.vendor.image')); ?>" enctype="multipart/form-data" class="dropzone" id="dropzone">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

			<section class="about-cards-section mb-5">
				<div class="container-fluid venue-gallery-container" data-aos="fade-up" data-aos-delay="100">
					<div class="col-md-10 m-auto">
						<div class="row">

							<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-3 col-md-4 mb-4">
									<div class="venue-gallery">
										<a href="<?php echo e(vendorImage($image->file_path)); ?>" class="glightbox" data-gall="venue-gallery">
											<img src="<?php echo e(vendorImage($image->file_path)); ?>" alt="" class="img-fluid">
										</a>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div>
				</div>
            </section>
        <?php endif; ?>

    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

    <script type="text/javascript">
		Dropzone.options.dropzone =
			{
				maxFilesize: 12,
				renameFile: function(file) {
					var dt = new Date();
					var time = dt.getTime();
					return time+file.name;
				},
				acceptedFiles: ".jpeg,.jpg,.png,.gif",
				addRemoveLinks: true,
				timeout: 5000,
				success: function(file, response)
				{
					console.log(response);
				},
				error: function(file, response)
				{
					return false;
				}
			};
    </script>

    <script>
		function updateProfile()
		{
			$('#profile').submit();
		}
		// $(document).ready(function() {
		//     $('.avatar').change(function() {
		//         console.log('Changed');
		//     });
		// });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/user/vendor/images.blade.php ENDPATH**/ ?>