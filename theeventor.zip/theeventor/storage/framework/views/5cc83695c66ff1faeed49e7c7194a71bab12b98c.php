<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                            <div class="card border-0">
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        <a href="<?php echo e(route('category', $category)); ?>" class="btn btn-sm btn-main">
                                            <?php echo e($category->name); ?>

                                        </a>

                                    </h3>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/categories.blade.php ENDPATH**/ ?>