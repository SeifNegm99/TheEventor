<div style="margin: 100px">
    vendor
</div>
<?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/homepage_vendor.blade.php ENDPATH**/ ?>