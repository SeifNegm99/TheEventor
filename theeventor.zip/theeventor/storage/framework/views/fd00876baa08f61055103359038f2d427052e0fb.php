<?php $__env->startSection('content'); ?>
    <div class="container main-container">
        <div class="row justify-content-center">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <strong>
                        <?php echo implode('<br/>', $errors->all('<span>:message</span>')); ?>

                    </strong>
                </div>
            <?php endif; ?>

                <div class="col-md-10">
                    <div class="card border-0">
                        <div class="card-body">

                            <div class="row mb-4">
                                <div class="col-12 text-center">
                                    <?php if(!empty($service->image)): ?>
                                        <img src="<?php echo e(vendorImage($service->image)); ?>" style="max-width:  200px;" class="mb-4">
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row">

                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-4 mb-4">
                                        <div class="venue-gallery">
                                            <a href="<?php echo e(vendorImage($image->file_path)); ?>" class="glightbox" data-gall="venue-gallery">
                                                <img src="<?php echo e(vendorImage($image->file_path)); ?>" alt="" class="img-fluid">
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>


                            <form method="POST" action="<?php echo e(route('update.vendor.service')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>



                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <input id="en_name" placeholder="<?php echo e(__('English Name')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['en_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="en_name" value="<?php echo e(old('en_name', @$service->en_name)); ?>" disabled disabled autocomplete="en_name" autofocus>

                                        <?php $__errorArgs = ['en_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 direction-rtl">
                                        <input id="ar_name" placeholder="<?php echo e(__('الاسم بالعربية')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['ar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ar_name" value="<?php echo e(old('ar_name', @$service->ar_name)); ?>" disabled autocomplete="ar_name">

                                        <?php $__errorArgs = ['ar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <div><?php echo $service->en_description; ?></div>
                                    </div>
                                    <div class="col-md-6">
                                        <div><?php echo $service->ar_description; ?></div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <span class="badge badge-secondary bi-text-left">
                                            <?php echo e($service->category->name); ?>

                                        </span>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/admin/service.blade.php ENDPATH**/ ?>