<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 card-wrapper">
                            <div class="card border-0">
                                <div class="position-relative rounded-circle overflow-hidden mx-auto custom-circle-image">
                                    <img class="w-100 h-100" src="<?php echo e(vendorServiceImage($service->image)); ?>" alt="Card image cap">
                                </div>
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        <?php echo e($service->en_name); ?>

                                        <?php echo e(!empty($service->ar_name) ? ' - ' . $service->ar_name : ''); ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/services.blade.php ENDPATH**/ ?>