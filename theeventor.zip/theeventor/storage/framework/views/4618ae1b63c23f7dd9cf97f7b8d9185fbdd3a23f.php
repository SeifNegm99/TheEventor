<?php $__env->startSection('content'); ?>
    <main id="main" class="main-container">
        <section class="about-cards-section">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 card-wrapper">
                            <div class="card border-0">
                                <div class="position-relative rounded-circle overflow-hidden mx-auto custom-circle-image">
                                    <img class="w-100 h-100" src="<?php echo e(vendorServiceImage($service->image)); ?>" alt="Card image cap">
                                </div>
                                <div class="card-body text-center mt-4">
                                    <h3 class="text-uppercase card-title">
                                        <?php if($service->approved == 1): ?>
                                            <p class="text-success"><?php echo e($service->en_name); ?></p>
                                        <?php elseif($service->approved == 0): ?>
                                            <p class="text-danger"><?php echo e($service->en_name); ?></p>
                                        <?php else: ?>
                                            <?php echo e($service->en_name); ?>

                                        <?php endif; ?>

                                        <?php echo e(!empty($service->ar_name) ? ' - ' . $service->ar_name : ''); ?>

                                    </h3>
                                    <div class="col-md-12 d-flex justify-content-center ">
                                        <form method="post" action="<?php echo e(route('admin.approve.service', ['service' => $service, 'status' => 1])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success me-2">Approve</button>
                                        </form>
                                        <form method="post" action="<?php echo e(route('admin.reject.service', ['service' => $service, 'status' => 0])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-danger me-2">Reject</button>
                                        </form>

                                        <a href="<?php echo e(route('admin.view.service', $service)); ?>" class="btn btn-sm btn-warning">View</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/admin/services.blade.php ENDPATH**/ ?>