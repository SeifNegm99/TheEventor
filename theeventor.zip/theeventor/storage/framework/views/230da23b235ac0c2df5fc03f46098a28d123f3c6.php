




<div style="margin: 100px">
    CustomerCustomerCustomerCustomerCustomerCustomer
    Customer
    Customer
    Customer
</div>
<?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/pages/homepage_customer.blade.php ENDPATH**/ ?>