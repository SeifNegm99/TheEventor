<?php $__env->startSection('content'); ?>
    <div class="container main-container">
        <div class="row justify-content-center">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <strong>
                        <?php echo implode('<br/>', $errors->all('<span>:message</span>')); ?>

                    </strong>
                </div>
            <?php endif; ?>

            <?php if($service && !$service->approved): ?>
                <div class="col-md-8 m-auto">
                    <p class="text-success">
                        Your request has been received and is being reviewed by our Team.

                    </p>
                    <p class="alert-danger">We kindly ask you not to submit further requests until you receive a response from us</p>
                </div>
            <?php else: ?>
                  <div class="col-md-10">
                        <div class="card border-0">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-12">
                                        <form method="post" action="<?php echo e(route('upload.vendor.image')); ?>" enctype="multipart/form-data" class="dropzone" id="dropzone">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </div>

                                <div class="row">

                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 mb-4">
                                            <div class="venue-gallery">
                                                <a href="<?php echo e(vendorImage($image->file_path)); ?>" class="glightbox" data-gall="venue-gallery">
                                                    <a href="<?php echo e(route('delete.vendor.image', $image)); ?>" class="remove-image">x</a>
                                                    <img src="<?php echo e(vendorImage($image->file_path)); ?>" alt="" class="img-fluid">
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <form method="POST" action="<?php echo e(route('update.vendor.service')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="row mb-4">
                                        <div class="col-12 text-center">
                                            <?php if(!empty($service->image)): ?>
                                                <img src="<?php echo e(vendorImage($service->image)); ?>" style="max-width:  200px;" class="mb-4">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="image">Featured Image</label>
                                            <?php if(empty($service->image)): ?>
                                                <input class="form-control" type="file" id="image" name="image" required>
                                            <?php else: ?>
                                                <input class="form-control" type="file" id="image" name="image">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="video">Featured Video</label>
                                            <input class="form-control" type="file" id="video" name="video">

                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <input id="en_name" placeholder="<?php echo e(__('English Name')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['en_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="en_name" value="<?php echo e(old('en_name', @$service->en_name)); ?>" required autocomplete="en_name" autofocus>

                                            <?php $__errorArgs = ['en_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 direction-rtl">
                                            <input id="ar_name" placeholder="<?php echo e(__('الاسم بالعربية')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['ar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ar_name" value="<?php echo e(old('ar_name', @$service->ar_name)); ?>" autocomplete="ar_name">

                                            <?php $__errorArgs = ['ar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <textarea class="rich-text-editor" name="en_description" id="en_description"><?php echo e(old('en_description', @$service->en_description)); ?></textarea>
                                        </div>
                                        <div class="col-md-6">
                                            <textarea class="rich-text-editor" name="ar_description" id="ar_description"><?php echo e(old('ar_description', @$service->ar_description)); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <div class="form-group mt-3">
                                            <select name="category_id" class="form-select">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php echo e(( old('category') == $category->id || @$service->category) ? 'selected': ''); ?>><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12">
                                            <input id="price" placeholder="<?php echo e(__('Price')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price', @$service->price)); ?>" autocomplete="price">

                                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <div class="col-md-4">
                                            <input id="long" placeholder="<?php echo e(__('Longitude')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="long" value="<?php echo e(old('long', @$service->long)); ?>" autocomplete="long">

                                            <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-4">
                                            <input id="lat" placeholder="<?php echo e(__('Latitude')); ?>" type="text" class="customInput form-control <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lat" value="<?php echo e(old('lat', @$service->lat)); ?>" autocomplete="lat">

                                            <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-4">
                                            <button type="button" class="btn btn-dark w-100" id="find-me">
                                                <i class="fa-solid fa-map-location"></i>
                                                Show Location
                                            </button>

                                        </div>
                                    </div>


                                    <div class="row mb-0 mt-4">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-dark w-100">
                                                <?php if(empty($service)): ?>
                                                    <?php echo e(__('Add')); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('Update')); ?>

                                                <?php endif; ?>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                </div>
            <?php endif; ?>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('tinymce/tinymce.min.js')); ?>" referrerpolicy="origin"></script>

    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

    <script type="text/javascript">
	    tinymce.init({
		    selector: '.rich-text-editor'
	    });

		Dropzone.options.dropzone =
			{
				maxFilesize: 12,
				renameFile: function(file) {
					var dt = new Date();
					var time = dt.getTime();
					return time+file.name;
				},
				acceptedFiles: ".jpeg,.jpg,.png,.gif",
				addRemoveLinks: true,
				timeout: 5000,
				success: function(file, response)
				{
					console.log(response);
				},
				error: function(file, response)
				{
					return false;
				}
			};


	    function geoFindMe() {

		    const status = document.querySelector('#long');
		    const mapLink = document.querySelector('#lat');

		    mapLink.href = '';
		    mapLink.textContent = '';

		    function success(position) {
			    const latitude  = position.coords.latitude;
			    const longitude = position.coords.longitude;
			    $('#long').val(longitude);
			    $('#lat').val(latitude);
			    console.log('www')
			    // status.textContent = '';
			    // mapLink.href = `https://www.openstreetmap.org/#map=18/${latitude}/${longitude}`;
			    // mapLink.textContent = `Latitude: ${latitude} °, Longitude: ${longitude} °`;
		    }

		    function error() {
			    status.textContent = 'Unable to retrieve your location';
		    }

		    if(!navigator.geolocation) {
			    status.textContent = 'Geolocation is not supported by your browser';
		    } else {
			    status.textContent = 'Locating…';
			    navigator.geolocation.getCurrentPosition(success, error);
		    }

	    }

	    document.querySelector('#find-me').addEventListener('click', geoFindMe);
    </script>

    <script>
		function updateProfile()
		{
			$('#profile').submit();
		}
		// $(document).ready(function() {
		//     $('.avatar').change(function() {
		//         console.log('Changed');
		//     });
		// });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/knizer/XcodeApps/Friends/Mariouma/theeventor/resources/views/web/user/vendor/service.blade.php ENDPATH**/ ?>