-- MariaDB dump 10.19  Distrib 10.8.3-MariaDB, for osx10.17 (arm64)
--
-- Host: 127.0.0.1    Database: theeventor
-- ------------------------------------------------------
-- Server version	10.8.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'venues',1,'2022-07-01 02:26:03',NULL),
(2,'photographers',2,'2022-07-01 02:26:03',NULL),
(3,'videographers',3,'2022-07-01 02:26:03',NULL),
(4,'Caterers',4,'2022-07-01 02:26:03',NULL),
(5,'cakes & desserts',5,'2022-07-01 02:26:03',NULL),
(6,'makeup artist',6,'2022-07-01 02:26:03',NULL),
(7,'sound systems & DJ',7,'2022-07-01 02:26:03',NULL),
(8,'florists',8,'2022-07-01 02:26:03',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `service_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_user_id_foreign` (`user_id`),
  KEY `files_service_id_foreign` (`service_id`),
  CONSTRAINT `files_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES
(1,'1656642326_16566423269541.jpg','/storage/users/1656642326_16566423269541.jpg',3,1,'2022-07-01 00:25:26','2022-07-01 00:26:25'),
(2,'1656642326_16566423269552.jpg','/storage/users/1656642326_16566423269552.jpg',3,1,'2022-07-01 00:25:26','2022-07-01 00:26:25'),
(3,'1656642327_16566423269563.jpg','/storage/users/1656642327_16566423269563.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25'),
(4,'1656642327_16566423269564.jpg','/storage/users/1656642327_16566423269564.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25'),
(5,'1656642327_16566423269565.jpg','/storage/users/1656642327_16566423269565.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25'),
(6,'1656642327_16566423269576.jpg','/storage/users/1656642327_16566423269576.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25'),
(7,'1656642327_16566423269577.jpg','/storage/users/1656642327_16566423269577.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25'),
(8,'1656642327_16566423269578.jpg','/storage/users/1656642327_16566423269578.jpg',3,1,'2022-07-01 00:25:27','2022-07-01 00:26:25');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
(5,'2022_06_29_000_create_services_table',1),
(6,'2022_06_29_00_create_categories_table',1),
(7,'2022_06_29_080109_create_files_table',1),
(8,'2022_07_01_022248_services_categories_relation',2),
(11,'2022_07_01_023547_services_missing_properties',3),
(12,'2022_07_02_025336_create_notifications_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
('0736b92b-2a2c-4bd6-9c40-748aec3b9b69','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qwe\",\"fromUser\":5}','2022-07-02 01:55:47','2022-07-02 01:55:42','2022-07-02 01:55:47'),
('1721df5a-739b-4e2d-9474-e376d7f60fd7','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:14','2022-07-02 01:53:06','2022-07-02 01:54:14'),
('2510cae8-c730-44ba-a8b2-78b1b57fa277','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:44','2022-07-02 01:54:42','2022-07-02 01:54:44'),
('27ea5653-5276-4348-a130-7fc757ac5132','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:14','2022-07-02 01:52:44','2022-07-02 01:54:14'),
('29ac6a46-9257-4fae-8d03-39a8277283cb','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qwe\",\"fromUser\":5}','2022-07-02 01:55:36','2022-07-02 01:55:35','2022-07-02 01:55:36'),
('3b277bb4-48ee-45df-a1c4-bdf17fc05a05','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:14','2022-07-02 01:52:56','2022-07-02 01:54:14'),
('40630ec4-37d7-4c79-b3bf-eeae7bb54a7e','App\\Notifications\\MessageSent','App\\Models\\User',1,'{\"message\":\"qweqweqweqwe\",\"fromUser\":5}',NULL,'2022-07-02 01:57:46','2022-07-02 01:57:46'),
('45fc9926-b42a-49f2-bec3-6d61b6a38a6f','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:44','2022-07-02 01:54:39','2022-07-02 01:54:44'),
('5bb0bd1c-a71b-4096-b256-38bc1e92a8cc','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:35','2022-07-02 01:54:34','2022-07-02 01:54:35'),
('64c3bc16-cdd2-4e63-825b-5a3fa53c5b63','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:23','2022-07-02 01:54:22','2022-07-02 01:54:23'),
('6b1f7eb9-b390-4b63-92f3-cec0d6f7c54a','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:54:44','2022-07-02 01:54:43','2022-07-02 01:54:44'),
('8917c871-be9a-438c-b961-bcd83616802e','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqweqwe\",\"fromUser\":5}','2022-07-02 01:54:14','2022-07-02 01:52:41','2022-07-02 01:54:14'),
('9829e164-1aba-429c-a355-7d4d244a13de','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqwe\",\"fromUser\":5}','2022-07-02 01:55:28','2022-07-02 01:54:47','2022-07-02 01:55:28'),
('dbe2538d-1ade-430a-a790-f1a066363367','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qwe\",\"fromUser\":5}','2022-07-02 01:55:47','2022-07-02 01:55:39','2022-07-02 01:55:47'),
('eb44de52-59b9-42e5-a179-bf9a9ad33a73','App\\Notifications\\MessageSent','App\\Models\\User',3,'{\"message\":\"qweqweqwe\",\"fromUser\":5}','2022-07-02 01:56:28','2022-07-02 01:56:26','2022-07-02 01:56:28');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `en_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ar_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `en_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ar_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `approved` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `price` double(8,2) NOT NULL,
  `long` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_user_id_foreign` (`user_id`),
  KEY `services_category_id_foreign` (`category_id`),
  CONSTRAINT `services_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES
(1,'/storage/services/1656642385_6.jpg','service 1 qwe qwe qwew','ض صثضصث ضصث ضصث','<p>qweqweqwe</p>','<p>ضصث ضصث ضصث ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>&nbsp;</p>',NULL,1,'1','2022-07-01 00:26:25','2022-07-02 00:12:24',8,120.20,'31.3521868','30.5194723'),
(2,'/storage/services/1656642385_6.jpg','service 1 qwe qwe qwew','ض صثضصث ضصث ضصث','<p>qweqweqwe</p>','<p>ضصث ضصث ضصث ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>&nbsp;</p>',NULL,3,'1','2022-07-01 00:26:25','2022-07-01 01:30:50',8,120.20,NULL,NULL),
(3,'/storage/services/1656642385_6.jpg','service 1 qwe qwe qwew','ض صثضصث ضصث ضصث','<p>qweqweqwe</p>','<p>ضصث ضصث ضصث ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>ضصث</p>\r\n<p>&nbsp;</p>',NULL,4,'1','2022-07-01 00:26:25','2022-07-01 01:30:50',8,120.20,NULL,NULL);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'faris','ahmed','city','faris@4serv.net','2022-06-30 22:37:45','$2y$10$HTmxPwh6B/70OQ34Umimzudm/tn9pLFClRReEBRKDd75PWa9h3NXW',2,'users/1656635865_1.jpg',NULL,'2022-06-30 22:37:45','2022-06-30 22:37:45'),
(2,'faris','ahmed','city','admin@theeventor.codeapps.cc','2022-06-30 22:37:45','$2y$10$HTmxPwh6B/70OQ34Umimzudm/tn9pLFClRReEBRKDd75PWa9h3NXW',3,'users/1656639505_8.jpg',NULL,'2022-06-30 22:37:45','2022-06-30 23:38:30'),
(3,'qweqwe','qweqweqwe','qweqweqwe','farisahmed.dev@gmail.com','2022-06-30 23:53:19','$2y$10$sYchw3XjGZ7s2UvBzzUAceY2fa04W2Tllb7r.KPADWePoiPQTmR8y',2,'users/1656640399_6.jpg',NULL,'2022-06-30 23:53:19','2022-06-30 23:53:19'),
(4,'qweqw','qweqwe','qwe','qwe@qwe.com','2022-07-01 00:17:24','$2y$10$jQV2oAN7JZaB9OgIIkFIgOljHGS14FkE3eIXv.Ey1r6S50LmFBrZu',2,'users/1656641844_3.jpg',NULL,'2022-07-01 00:17:24','2022-07-01 00:17:24'),
(5,'faris','ahmed','qkwejqwe','faris@ana.ae','2022-07-01 01:31:37','$2y$10$56GiyVzlYD7I.73SHpx8Vuhcg2tR3t4TOQODliv/DbQu3OaNwCnFK',1,'users/1656646297_1.jpg',NULL,'2022-07-01 01:31:37','2022-07-01 01:31:37');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-02  5:58:39
