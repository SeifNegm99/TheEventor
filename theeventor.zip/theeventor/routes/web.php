<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\WebController::class, 'home'])->name('theEventor');

Route::get('/login', function() {
	return redirect('/');
})->name('login');

Route::get('/home', function() {
	return redirect('/');
})->name('home');

Route::get('/register', [\App\Http\Controllers\Auth\RegisterController::class, 'createUser'])->name('register.user');
Route::post('/register_customer', [\App\Http\Controllers\Auth\RegisterController::class, 'createUser'])->name('register.user');

Route::get('/services', [\App\Http\Controllers\WebController::class, 'services'])->name('services');
Route::get('/categories', [\App\Http\Controllers\WebController::class, 'categories'])->name('categories');
Route::get('/category/{category}', [\App\Http\Controllers\WebController::class, 'category'])->name('category');
Route::get('/service/{service}', [\App\Http\Controllers\WebController::class, 'service'])->name('service');
Route::post('/service/{service}', [\App\Http\Controllers\WebController::class, 'service'])->name('send.vendor.message');
Route::get('/notifications', [\App\Http\Controllers\WebController::class, 'notifications'])->name('notifications');

\Illuminate\Support\Facades\Auth::routes();



Route::get('/profile', [\App\Http\Controllers\ProfileController::class, 'profile'])->middleware(['auth'])->name('user.profile');
Route::post('/profile/update/avatar', [\App\Http\Controllers\ProfileController::class, 'updateAvatar'])->middleware(['auth'])->name('update.profile.avatar');
Route::post('/profile/update/name', [\App\Http\Controllers\ProfileController::class, 'updateName'])->middleware(['auth'])->name('update.profile.name');

Route::get('/vendor/images', [\App\Http\Controllers\VendorController::class, 'all'])->middleware(['auth', 'isVendor'])->name('vendor.images');

Route::post('/vendor/images', [\App\Http\Controllers\VendorController::class, 'images'])->middleware(['auth', 'isVendor'])->name('upload.vendor.image');
Route::get('/vendor/images/delete/{file}', [\App\Http\Controllers\VendorController::class, 'delete'])->middleware(['auth', 'isVendor'])->name('delete.vendor.image');


//Route::get('/vendor/services', [\App\Http\Controllers\VendorController::class, 'services'])->middleware(['auth', 'isVendor'])->name('vendor.services');
Route::post('/vendor/service', [\App\Http\Controllers\VendorController::class, 'service'])->middleware(['auth', 'isVendor'])->name('update.vendor.service');

Route::get('/vendor/service', [\App\Http\Controllers\VendorController::class, 'service'])->middleware(['auth', 'isVendor'])->name('vendor.service');





Route::get('/admin/services/status/{service}/{status}', [\App\Http\Controllers\DashboardController::class, 'updateServiceStatus'])->middleware(['auth', 'isAdmin'])->name('admin.approve.service');
Route::post('/admin/services/status/{service}/{status}', [\App\Http\Controllers\DashboardController::class, 'updateServiceStatus'])->middleware(['auth', 'isAdmin'])->name('admin.reject.service');

Route::get('/admin/services', [\App\Http\Controllers\DashboardController::class, 'index'])->middleware(['auth', 'isAdmin'])->name('admin.services');
Route::get('/admin/service/view/{service}', [\App\Http\Controllers\DashboardController::class, 'service'])->middleware(['auth', 'isAdmin'])->name('admin.view.service');

